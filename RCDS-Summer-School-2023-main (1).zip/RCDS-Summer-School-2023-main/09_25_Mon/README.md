# RCDS Summer School 2023
#### Imperial College London

## Day 1
Welcome to Day 1.
