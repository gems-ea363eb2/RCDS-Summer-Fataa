# RCDS Summer School 2023
#### Imperial College London

## Day 2
Welcome to Day 2.
