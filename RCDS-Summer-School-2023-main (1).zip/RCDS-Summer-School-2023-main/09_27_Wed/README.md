# RCDS Summer School 2023
#### Imperial College London

## Day 3
Welcome to Day 3.
