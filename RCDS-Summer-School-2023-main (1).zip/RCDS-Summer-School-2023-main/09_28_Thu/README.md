# RCDS Summer School 2023
#### Imperial College London

## Day 4
Welcome to Day 4.
