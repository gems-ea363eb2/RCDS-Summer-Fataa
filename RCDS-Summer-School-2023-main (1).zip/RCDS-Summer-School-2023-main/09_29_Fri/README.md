# RCDS Summer School 2023
#### Imperial College London

## Day 5
Welcome to Day 5.
